// Your complete website code goes here
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function NextKidneyWebsite() {
  return (
    <div className="font-sans">
      <section className="bg-black text-white text-center py-24 px-4">
        <motion.h1 className="text-5xl font-bold mb-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>Wear Your Brand. Show Your Story.</motion.h1>
        <p className="text-xl mb-8">High-quality T-shirt printing, standout signage, and full branding solutions.</p>
        <div className="flex justify-center gap-4">
          <Button className="bg-green-500 text-white">Get a Quote</Button>
          <Button variant="outline" className="border-white text-white">View Portfolio</Button>
        </div>
      </section>
      {/* You can add the rest of sections here as in the code provided */}
    </div>
  );
}
